from django.apps import AppConfig


class PackageConfig(AppConfig):
    name = 'package'
